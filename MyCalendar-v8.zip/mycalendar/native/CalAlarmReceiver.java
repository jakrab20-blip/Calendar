package com.mycalendar.app;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;
public class CalAlarmReceiver extends BroadcastReceiver {
  static final int MAXA = 200;
  static final int TEST_ID = 9001;
  static final int REFILL_ID = 9002;
  static final String CH = "calalarm_v8";
  static final String CH_INFO = "calinfo_v8";
  static final String ACT_ACK = "com.mycalendar.app.ACK";
  static final String ACT_SNOOZE = "com.mycalendar.app.SNOOZE";

  static PendingIntent bpi(Context c, int id, Intent i) {
    return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }
  static String s(String x) { return x == null ? "" : x; }
  static int snoozeMin(Context c) {
    int m = c.getSharedPreferences("mycal", 0).getInt("snz", 10);
    return (m < 1 || m > 120) ? 10 : m;
  }
  static Intent alarmIntent(Context c, int id, String t, String b, String tm, String cat, String loc) {
    return new Intent(c, CalAlarmReceiver.class).putExtra("id", id).putExtra("t", t).putExtra("b", b).putExtra("tm", tm).putExtra("c", cat).putExtra("l", loc);
  }
  static void setAt(Context c, int id, long at, Intent i) {
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    PendingIntent p = bpi(c, id, i);
    try {
      if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
      else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
    } catch (Exception e) {
      try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p); } catch (Exception x) { }
    }
  }
  static void cancelId(Context c, int id) {
    try {
      AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
      PendingIntent p = PendingIntent.getBroadcast(c, id, new Intent(c, CalAlarmReceiver.class), PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
      if (p != null) { am.cancel(p); p.cancel(); }
    } catch (Exception e) { }
  }
  static void snoozeAlarm(Context c, String t, String tm, String cat, String loc, int min) {
    int id = 5000 + Math.abs((t + "|" + tm).hashCode() % 900);
    setAt(c, id, System.currentTimeMillis() + min * 60000L, alarmIntent(c, id, t, "เลื่อนเตือนมาแล้ว", tm, cat, loc));
  }
  public static void scheduleAll(Context c, boolean fromApp) {
    for (int id = 1; id <= MAXA; id++) cancelId(c, id);
    cancelId(c, REFILL_ID);
    SharedPreferences sp = c.getSharedPreferences("mycal", 0);
    JSONArray a;
    try { a = new JSONArray(sp.getString("alarms", "[]")); } catch (Exception e) { a = new JSONArray(); }
    long now = System.currentTimeMillis();
    for (int k = 0; k < a.length(); k++) {
      try {
        JSONObject o = a.getJSONObject(k);
        long at = o.optLong("at");
        if (at <= now) continue;
        int id = o.optInt("id", k + 1);
        if (id < 1 || id > MAXA) continue;
        setAt(c, id, at, alarmIntent(c, id, o.optString("title"), o.optString("body"), o.optString("tm"), o.optString("cat"), o.optString("loc")));
      } catch (Exception e) { }
    }
    long renew = sp.getLong("renew", 0);
    if (a.length() > 0 && renew > 0) {
      if (renew > now) setAt(c, REFILL_ID, renew, new Intent(c, CalAlarmReceiver.class).putExtra("kind", "refill"));
      else if (!fromApp) setAt(c, REFILL_ID, now + 60000L, new Intent(c, CalAlarmReceiver.class).putExtra("kind", "refill"));
    }
  }
  static void postRefill(Context c, NotificationManager nm) {
    try {
      if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH_INFO, "แจ้งให้ต่ออายุการเตือน", NotificationManager.IMPORTANCE_DEFAULT));
      Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
      NotificationCompat.Builder nb = new NotificationCompat.Builder(c, CH_INFO).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("เปิดแอปปฏิทินเพื่อต่ออายุการเตือน").setContentText("แตะเพื่อเปิดแอปสักครั้ง ไม่เช่นนั้นนัดที่ซ้ำอาจไม่เตือน").setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT);
      if (li != null) nb.setContentIntent(PendingIntent.getActivity(c, 2000, li, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
      nm.notify(REFILL_ID, nb.build());
    } catch (Exception e) { }
  }
  @Override public void onReceive(Context c, Intent i) {
    NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    String act = i.getAction();
    int id = i.getIntExtra("id", 0);
    if (ACT_ACK.equals(act)) {
      try { nm.cancel(id); } catch (Exception e) { }
      return;
    }
    String t = s(i.getStringExtra("t")), b = s(i.getStringExtra("b")), tm = s(i.getStringExtra("tm")), cat = s(i.getStringExtra("c")), loc = s(i.getStringExtra("l"));
    if (ACT_SNOOZE.equals(act)) {
      try { nm.cancel(id); } catch (Exception e) { }
      snoozeAlarm(c, t, tm, cat, loc, snoozeMin(c));
      return;
    }
    if ("refill".equals(i.getStringExtra("kind"))) { postRefill(c, nm); return; }
    Uri u = new Uri.Builder().scheme("mycalendar").authority("alert").appendQueryParameter("t", t).appendQueryParameter("tm", tm).appendQueryParameter("c", cat).appendQueryParameter("l", loc).build();
    Intent open = new Intent(Intent.ACTION_VIEW, u).setPackage(c.getPackageName()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent pi = PendingIntent.getActivity(c, 1000 + id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    boolean saw = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    Uri snd = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
    if (snd == null) snd = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
    long[] vib = new long[]{0, 800, 400, 800, 400, 800};
    if (Build.VERSION.SDK_INT >= 26) {
      try { nm.deleteNotificationChannel("calalarm_q"); nm.deleteNotificationChannel("calalarm_l"); } catch (Exception e) { }
      NotificationChannel x = new NotificationChannel(CH, "นัดหมาย (เสียงปลุก)", NotificationManager.IMPORTANCE_HIGH);
      x.enableVibration(true);
      x.setVibrationPattern(vib);
      x.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
      x.setSound(snd, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
      nm.createNotificationChannel(x);
    }
    try {
      Intent ai = new Intent(c, CalAlarmReceiver.class).setAction(ACT_ACK).putExtra("id", id);
      Intent si = new Intent(c, CalAlarmReceiver.class).setAction(ACT_SNOOZE).putExtra("id", id).putExtra("t", t).putExtra("tm", tm).putExtra("c", cat).putExtra("l", loc);
      NotificationCompat.Builder nb = new NotificationCompat.Builder(c, CH).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(t).setContentText(b).setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setAutoCancel(true).setContentIntent(pi).setFullScreenIntent(pi, true).setTimeoutAfter(120000L).addAction(android.R.drawable.ic_menu_close_clear_cancel, "รับทราบ", bpi(c, 20000 + id, ai)).addAction(android.R.drawable.ic_lock_idle_alarm, "เลื่อน " + snoozeMin(c) + " นาที", bpi(c, 30000 + id, si));
      if (Build.VERSION.SDK_INT < 26) nb.setSound(snd, AudioManager.STREAM_ALARM).setVibrate(vib);
      Notification n = nb.build();
      n.flags |= Notification.FLAG_INSISTENT;
      nm.notify(id, n);
    } catch (Exception e) { }
    if (saw) { try { c.startActivity(open); } catch (Exception e) { } }
  }
}
