ปฏิทินของฉัน - โปรเจกต์แอป (Capacitor)
1) ใน repo สร้างไฟล์ .github/workflows/build-apk.yml (ครั้งเดียว) จากไฟล์ build-apk.yml
2) อัปโหลดไฟล์ zip นี้ขึ้น repo (ไม่ต้องแตกไฟล์)
3) แท็บ Actions > Build APK > ดาวน์โหลด artifact MyCalendar-APK
