import shutil,os
A="android/app/src/main/"
shutil.copytree("native/res",A+"res",dirs_exist_ok=True)
d=A+"java/com/mycalendar/app/";os.makedirs(d,exist_ok=True);[shutil.copy("native/"+f,d) for f in os.listdir("native") if f.endswith(".java")]
M=A+"AndroidManifest.xml";m=open(M,encoding="utf-8").read()
r='<receiver android:name=".AddWidget" android:exported="true" android:label="เพิ่มนัดหมาย"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="android.intent.action.DATE_CHANGED"/><action android:name="android.intent.action.TIME_SET"/><action android:name="android.intent.action.TIMEZONE_CHANGED"/></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/add_widget_info"/></receiver>'
f='<intent-filter><action android:name="android.intent.action.VIEW"/><category android:name="android.intent.category.DEFAULT"/><category android:name="android.intent.category.BROWSABLE"/><data android:scheme="mycalendar"/></intent-filter>'
q='<queries><intent><action android:name="android.intent.action.TTS_SERVICE"/></intent></queries>'
m=m.replace("</application>",r+"</application>",1).replace("</activity>",f+"</activity>",1).replace("<application",q+"<application",1)
open(M,"w",encoding="utf-8").write(m);print("native patched")
