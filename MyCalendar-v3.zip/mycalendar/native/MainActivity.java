package com.mycalendar.app;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle b) { registerPlugin(TodayWidgetPlugin.class); super.onCreate(b); }
}
