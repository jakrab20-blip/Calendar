package com.mycalendar.app;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;
import java.util.Calendar;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;
public class AddWidget extends AppWidgetProvider {
  static final String[] M = {"ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค."};
  public static void refresh(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, AddWidget.class));
    if (ids.length > 0) new AddWidget().onUpdate(c, m, ids);
  }
  @Override public void onReceive(Context c, Intent i) {
    super.onReceive(c, i);
    String a = i.getAction();
    if (Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) refresh(c);
  }
  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
    Calendar k = Calendar.getInstance();
    String key = String.format(Locale.US, "%04d-%02d-%02d", k.get(Calendar.YEAR), k.get(Calendar.MONTH) + 1, k.get(Calendar.DAY_OF_MONTH));
    String body = "เปิดแอปหนึ่งครั้งเพื่อโหลดนัดหมาย";
    try {
      JSONObject o = new JSONObject(c.getSharedPreferences("mycal", 0).getString("w", "{}"));
      if (o.has(key)) {
        JSONArray a = o.getJSONArray(key);
        if (a.length() == 0) body = "วันนี้ไม่มีนัดหมาย";
        else {
          StringBuilder sb = new StringBuilder();
          for (int n = 0; n < a.length() && n < 6; n++) sb.append(a.getString(n)).append("\n");
          if (a.length() > 6) sb.append("+อีก ").append(a.length() - 6).append(" รายการ");
          body = sb.toString().trim();
        }
      }
    } catch (Exception e) { }
    Intent add = new Intent(Intent.ACTION_VIEW, Uri.parse("mycalendar://add")).setPackage(c.getPackageName()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    PendingIntent pa = PendingIntent.getActivity(c, 0, add, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
    PendingIntent po = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    for (int id : ids) {
      RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_add);
      v.setTextViewText(R.id.w_title, "วันนี้ " + k.get(Calendar.DAY_OF_MONTH) + " " + M[k.get(Calendar.MONTH)]);
      v.setTextViewText(R.id.w_body, body);
      v.setOnClickPendingIntent(R.id.w_root, po);
      v.setOnClickPendingIntent(R.id.w_add, pa);
      m.updateAppWidget(id, v);
    }
  }
}
