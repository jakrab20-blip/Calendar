package com.mycalendar.app;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;
public class AddWidget extends AppWidgetProvider {
  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("mycalendar://add")).setPackage(c.getPackageName()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    PendingIntent p = PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    for (int id : ids) { RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_add); v.setOnClickPendingIntent(R.id.w_root, p); m.updateAppWidget(id, v); }
  }
}
