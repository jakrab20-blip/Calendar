package com.mycalendar.app;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.util.TypedValue;
import android.widget.RemoteViews;
import java.util.Calendar;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;
public class AddWidget extends AppWidgetProvider {
  static final String[] M = {"ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค."};
  public static void refresh(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, AddWidget.class));
    if (ids.length > 0) new AddWidget().onUpdate(c, m, ids);
  }
  static int pc(String s, int d) { try { return Color.parseColor(s); } catch (Exception e) { return d; } }
  @Override public void onReceive(Context c, Intent i) {
    super.onReceive(c, i);
    String a = i.getAction();
    if (Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) refresh(c);
  }
  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
    Calendar k = Calendar.getInstance();
    String key = String.format(Locale.US, "%04d-%02d-%02d", k.get(Calendar.YEAR), k.get(Calendar.MONTH) + 1, k.get(Calendar.DAY_OF_MONTH));
    String body = "เปิดแอปหนึ่งครั้งเพื่อโหลดนัดหมาย";
    int bg = 0xFF5b5bf0, tc = 0xFFFFFFFF, sz = 13, max = 6, op = 100;
    try {
      JSONObject root = new JSONObject(c.getSharedPreferences("mycal", 0).getString("w", "{}"));
      JSONObject cfg = root.optJSONObject("cfg");
      JSONObject days = root.optJSONObject("days");
      if (days == null) days = root;
      if (cfg != null) { bg = pc(cfg.optString("c"), bg); tc = pc(cfg.optString("tc"), tc); sz = cfg.optInt("sz", 13); max = cfg.optInt("n", 6); op = cfg.optInt("op", 100); }
      if (days.has(key)) {
        JSONArray a = days.getJSONArray(key);
        if (a.length() == 0) body = "วันนี้ไม่มีนัดหมาย";
        else {
          StringBuilder sb = new StringBuilder();
          for (int q = 0; q < a.length() && q < max; q++) sb.append(a.getString(q)).append("\n");
          if (a.length() > max) sb.append("+อีก ").append(a.length() - max).append(" รายการ");
          body = sb.toString().trim();
        }
      }
    } catch (Exception e) { }
    Intent add = new Intent(Intent.ACTION_VIEW, Uri.parse("mycalendar://add")).setPackage(c.getPackageName()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    PendingIntent pa = PendingIntent.getActivity(c, 0, add, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
    PendingIntent po = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    for (int id : ids) {
      RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_add);
      v.setInt(R.id.w_bg, "setColorFilter", bg | 0xFF000000);
      v.setInt(R.id.w_bg, "setImageAlpha", op * 255 / 100);
      v.setTextColor(R.id.w_title, tc);
      v.setTextColor(R.id.w_body, tc);
      v.setTextColor(R.id.w_add, bg | 0xFF000000);
      v.setTextViewTextSize(R.id.w_body, TypedValue.COMPLEX_UNIT_SP, sz);
      v.setInt(R.id.w_body, "setMaxLines", max + 1);
      v.setTextViewText(R.id.w_title, "วันนี้ " + k.get(Calendar.DAY_OF_MONTH) + " " + M[k.get(Calendar.MONTH)]);
      v.setTextViewText(R.id.w_body, body);
      v.setOnClickPendingIntent(R.id.w_root, po);
      v.setOnClickPendingIntent(R.id.w_add, pa);
      m.updateAppWidget(id, v);
    }
  }
}
