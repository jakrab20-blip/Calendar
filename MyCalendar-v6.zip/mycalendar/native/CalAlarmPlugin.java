package com.mycalendar.app;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
@CapacitorPlugin(name = "CalAlarm")
public class CalAlarmPlugin extends Plugin {
  @PluginMethod public void schedule(PluginCall call) {
    try {
      JSArray a = call.getArray("items");
      Context c = getContext();
      c.getSharedPreferences("mycal", 0).edit().putString("alarms", a.toString()).apply();
      CalAlarmReceiver.scheduleAll(c);
      call.resolve();
    } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
  }
  @PluginMethod public void check(PluginCall call) {
    Context c = getContext();
    JSObject r = new JSObject();
    r.put("overlay", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c));
    NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    r.put("fsi", Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent());
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    r.put("exact", Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms());
    call.resolve(r);
  }
  @PluginMethod public void openSettings(PluginCall call) {
    String w = call.getString("what", "overlay");
    Uri u = Uri.parse("package:" + getContext().getPackageName());
    Intent i;
    if (w.equals("fsi")) i = new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", u);
    else if (w.equals("exact")) i = new Intent("android.settings.REQUEST_SCHEDULE_EXACT_ALARM", u);
    else if (w.equals("battery")) i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
    else i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, u);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    try { getContext().startActivity(i); }
    catch (Exception e) { try { getContext().startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception x) { } }
    call.resolve();
  }
  @PluginMethod public void showOverLock(PluginCall call) {
    final boolean on = call.getBoolean("on", false);
    final Activity a = getActivity();
    if (a != null) a.runOnUiThread(new Runnable() { public void run() { MainActivity.lock(a, on); } });
    if (!on) { try { ((NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE)).cancelAll(); } catch (Exception e) { } }
    call.resolve();
  }
}
