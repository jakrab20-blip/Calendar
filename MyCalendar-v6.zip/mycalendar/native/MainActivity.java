package com.mycalendar.app;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  static void lock(Activity a, boolean on) {
    if (Build.VERSION.SDK_INT >= 27) { a.setShowWhenLocked(on); a.setTurnScreenOn(on); }
    else if (on) a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
    else a.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
  }
  static boolean isAlert(Intent i) { return i != null && i.getData() != null && "alert".equals(i.getData().getHost()); }
  @Override public void onCreate(Bundle b) {
    registerPlugin(TodayWidgetPlugin.class);
    registerPlugin(CalAlarmPlugin.class);
    super.onCreate(b);
    lock(this, isAlert(getIntent()));
  }
  @Override protected void onNewIntent(Intent i) {
    super.onNewIntent(i);
    if (isAlert(i)) lock(this, true);
  }
}
