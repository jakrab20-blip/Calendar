package com.mycalendar.app;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.SpannableStringBuilder;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.widget.RemoteViews;
import java.util.Calendar;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;
public class AddWidget extends AppWidgetProvider {
  static final String[] M = {"ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค."};
  static final String[] D = {"อาทิตย์","จันทร์","อังคาร","พุธ","พฤหัสบดี","ศุกร์","เสาร์"};
  static final String HOL = "วันหยุด: ";
  public static void refresh(Context c) {
    AppWidgetManager m = AppWidgetManager.getInstance(c);
    int[] ids = m.getAppWidgetIds(new ComponentName(c, AddWidget.class));
    if (ids.length > 0) new AddWidget().onUpdate(c, m, ids);
  }
  static int pc(String s, int d) { try { return Color.parseColor(s); } catch (Exception e) { return d; } }
  @Override public void onReceive(Context c, Intent i) {
    super.onReceive(c, i);
    String a = i.getAction();
    if (Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) refresh(c);
  }
  @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
    Calendar k = Calendar.getInstance();
    String key = String.format(Locale.US, "%04d-%02d-%02d", k.get(Calendar.YEAR), k.get(Calendar.MONTH) + 1, k.get(Calendar.DAY_OF_MONTH));
    int bg = 0xFF6C5CE7, tc = 0xFFFFFFFF, sz = 13, max = 6, op = 100, cnt = 0;
    SpannableStringBuilder sb = new SpannableStringBuilder();
    try {
      JSONObject root = new JSONObject(c.getSharedPreferences("mycal", 0).getString("w", "{}"));
      JSONObject cfg = root.optJSONObject("cfg");
      JSONObject days = root.optJSONObject("days");
      if (days == null) days = root;
      if (cfg != null) { bg = pc(cfg.optString("c"), bg); tc = pc(cfg.optString("tc"), tc); sz = cfg.optInt("sz", 13); max = cfg.optInt("n", 6); op = cfg.optInt("op", 100); }
      if (!days.has(key)) sb.append("เปิดแอปหนึ่งครั้งเพื่อโหลดนัดหมาย");
      else {
        JSONArray a = days.getJSONArray(key);
        for (int q = 0; q < a.length(); q++) if (!a.getString(q).startsWith(HOL)) cnt++;
        if (a.length() == 0) sb.append("วันนี้ไม่มีนัด พักผ่อนได้เลย");
        for (int q = 0; q < a.length() && q < max; q++) {
          String ln = a.getString(q);
          if (sb.length() > 0) sb.append("\n");
          int st = sb.length();
          if (ln.startsWith(HOL)) {
            sb.append("★ ").append(ln.substring(HOL.length()));
            sb.setSpan(new StyleSpan(Typeface.BOLD), st, sb.length(), 0);
          } else {
            int sp = ln.indexOf(' ');
            if (sp > 0) {
              sb.append(ln.substring(0, sp));
              sb.setSpan(new StyleSpan(Typeface.BOLD), st, sb.length(), 0);
              sb.append("  ").append(ln.substring(sp + 1));
            } else sb.append(ln);
          }
        }
        if (a.length() > max) sb.append("\n+อีก ").append(String.valueOf(a.length() - max)).append(" รายการ");
      }
    } catch (Exception e) { }
    int solid = bg | 0xFF000000;
    int soft = (tc & 0x00FFFFFF) | 0xB3000000;
    Intent add = new Intent(Intent.ACTION_VIEW, Uri.parse("mycalendar://add")).setPackage(c.getPackageName()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    PendingIntent pa = PendingIntent.getActivity(c, 0, add, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
    PendingIntent po = PendingIntent.getActivity(c, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    String my = M[k.get(Calendar.MONTH)] + " " + (k.get(Calendar.YEAR) + 543) + (cnt > 0 ? " · " + cnt + " นัด" : "");
    for (int id : ids) {
      RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_add);
      v.setInt(R.id.w_bg, "setColorFilter", solid);
      v.setInt(R.id.w_bg, "setImageAlpha", op * 255 / 100);
      v.setInt(R.id.w_addbg, "setColorFilter", tc | 0xFF000000);
      v.setInt(R.id.w_addbg, "setImageAlpha", 51);
      v.setInt(R.id.w_div, "setBackgroundColor", (tc & 0x00FFFFFF) | 0x33000000);
      v.setTextViewText(R.id.w_day, String.valueOf(k.get(Calendar.DAY_OF_MONTH)));
      v.setTextViewText(R.id.w_wd, D[k.get(Calendar.DAY_OF_WEEK) - 1]);
      v.setTextViewText(R.id.w_my, my);
      v.setTextViewText(R.id.w_body, sb);
      v.setTextColor(R.id.w_day, tc);
      v.setTextColor(R.id.w_wd, tc);
      v.setTextColor(R.id.w_my, soft);
      v.setTextColor(R.id.w_add, tc);
      v.setTextColor(R.id.w_body, tc);
      v.setTextViewTextSize(R.id.w_body, TypedValue.COMPLEX_UNIT_SP, sz);
      v.setInt(R.id.w_body, "setMaxLines", max + 1);
      v.setOnClickPendingIntent(R.id.w_root, po);
      v.setOnClickPendingIntent(R.id.w_add, pa);
      m.updateAppWidget(id, v);
    }
  }
}
