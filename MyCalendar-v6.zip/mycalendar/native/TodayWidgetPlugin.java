package com.mycalendar.app;
import android.content.Context;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
@CapacitorPlugin(name = "TodayWidget")
public class TodayWidgetPlugin extends Plugin {
  @PluginMethod public void set(PluginCall call) {
    Context c = getContext();
    c.getSharedPreferences("mycal", 0).edit().putString("w", call.getString("json", "{}")).apply();
    AddWidget.refresh(c);
    call.resolve();
  }
}
