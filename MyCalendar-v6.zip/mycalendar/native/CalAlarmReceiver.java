package com.mycalendar.app;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;
public class CalAlarmReceiver extends BroadcastReceiver {
  static PendingIntent bpi(Context c, int id, Intent i) {
    return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }
  static String s(String x) { return x == null ? "" : x; }
  public static void scheduleAll(Context c) {
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    for (int id = 1; id <= 60; id++) am.cancel(bpi(c, id, new Intent(c, CalAlarmReceiver.class)));
    JSONArray a;
    try { a = new JSONArray(c.getSharedPreferences("mycal", 0).getString("alarms", "[]")); } catch (Exception e) { return; }
    long now = System.currentTimeMillis();
    boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
    for (int k = 0; k < a.length(); k++) {
      try {
        JSONObject o = a.getJSONObject(k);
        long at = o.optLong("at");
        if (at <= now) continue;
        int id = o.optInt("id", k + 1);
        Intent i = new Intent(c, CalAlarmReceiver.class).putExtra("id", id).putExtra("t", o.optString("title")).putExtra("b", o.optString("body")).putExtra("tm", o.optString("tm")).putExtra("c", o.optString("cat")).putExtra("l", o.optString("loc"));
        PendingIntent p = bpi(c, id, i);
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
      } catch (Exception e) { }
    }
  }
  @Override public void onReceive(Context c, Intent i) {
    int id = i.getIntExtra("id", 0);
    String t = s(i.getStringExtra("t")), b = s(i.getStringExtra("b"));
    Uri u = new Uri.Builder().scheme("mycalendar").authority("alert").appendQueryParameter("t", t).appendQueryParameter("tm", s(i.getStringExtra("tm"))).appendQueryParameter("c", s(i.getStringExtra("c"))).appendQueryParameter("l", s(i.getStringExtra("l"))).build();
    Intent open = new Intent(Intent.ACTION_VIEW, u).setPackage(c.getPackageName()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent pi = PendingIntent.getActivity(c, 1000 + id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    boolean saw = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    String ch = saw ? "calalarm_q" : "calalarm_l";
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel x = new NotificationChannel(ch, saw ? "นัดหมาย (เด้งเต็มจอ)" : "นัดหมาย (เสียงเตือน)", NotificationManager.IMPORTANCE_HIGH);
      x.enableVibration(true);
      x.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
      if (saw) x.setSound(null, null);
      else x.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
      nm.createNotificationChannel(x);
    }
    try {
      NotificationCompat.Builder nb = new NotificationCompat.Builder(c, ch).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(t).setContentText(b).setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setAutoCancel(true).setContentIntent(pi).setFullScreenIntent(pi, true);
      nm.notify(id, nb.build());
    } catch (Exception e) { }
    if (saw) { try { c.startActivity(open); } catch (Exception e) { } }
  }
}
