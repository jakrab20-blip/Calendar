ปฏิทินของฉัน v2 (Capacitor)
1) ใน repo ใช้ไฟล์ .github/workflows/build-apk.yml ตัวใหม่ (build-apk.yml)
2) อัปโหลดไฟล์ zip นี้ขึ้น repo (ไม่ต้องแตกไฟล์)
3) แท็บ Actions > Build APK > ดาวน์โหลด MyCalendar-APK
Widget: กดค้างหน้าจอหลัก > วิดเจ็ต > เพิ่มนัดหมาย
